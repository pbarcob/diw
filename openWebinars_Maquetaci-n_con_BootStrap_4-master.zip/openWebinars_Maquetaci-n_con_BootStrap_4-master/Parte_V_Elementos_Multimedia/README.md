
# Parte V Elementos multimedia

Aunque anteriormente hemos hablado de cómo tratar las imágenes en BooStrap 4  hemos creído que era adecuado hablar de elementos más de los que BooStrap 4 se ocupa a la hora de dar estilos y a la hora de hacerlos responsivos.


1. El objeto media
2. Los elementos embebidos o incrustados desde otras páginas.
