
# Parte III: Maquetando el Layout

1. Contenedores.
2. El Grid de BootStrap 4.
3. Breakpoints de BootStrap 4.
4. Dimensionando columnas.
5. Desplazamientos de columnas.
6. Alineación en filas.
7. Ordenados columnas.
8. Márgenes y paddings en las columnas.
9. Anidando filas.
