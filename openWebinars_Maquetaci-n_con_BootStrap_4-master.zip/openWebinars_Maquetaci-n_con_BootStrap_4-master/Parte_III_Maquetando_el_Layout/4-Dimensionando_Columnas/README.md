# 4. Dimensionando columnas

4.1. Definido por el usuario

4.2. Auto

4.3. Saltos de línea

4.4. Gutter
