
# Requisitos

Requisitos para poder realizar el curso con éxito

* HTML
* CSS
* SASS


Y si no, ya sabeís

*El aprendizaje no es un deporte de espectadores*
*D. Blocher*
