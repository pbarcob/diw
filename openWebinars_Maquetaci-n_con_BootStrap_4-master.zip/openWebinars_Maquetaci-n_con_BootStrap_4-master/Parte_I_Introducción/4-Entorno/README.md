
# Entorno para el curso

Para este curso vamos a usar las siguiente herramientas:

* Editor Atom
* Consola del navegador (Ya sea para Chrome o para Firefox )
* Git/GitHub para la gestión de versiones.
